export const colors = {
  bg: '#0F1115',
  panel: '#171A21',
  panelRaised: '#20242D',
  border: '#2A2F3A',
  text: '#F2F4F8',
  textDim: '#9AA3B2',
  accent: '#F5B841',
  record: '#E5484D',
  ok: '#3FB950',
};

/** Ink colors that stay readable on white slides and after video compression. */
export const inkColors = ['#111111', '#1E3A8A', '#C62828', '#1B7F3B', '#E8590C', '#7B2CBF', '#FFD400'];

/** Ink widths as a fraction of the slide width. */
export const inkWidths = [
  { label: 'Thin', value: 0.0022 },
  { label: 'Medium', value: 0.0035 },
  { label: 'Thick', value: 0.006 },
];

/** Video bitrate for a 1920x1080 frame; the recorder scales it for other sizes. */
export const BASE_BITRATE = 16_000_000;
