import { useState } from 'react';
import { ActivityIndicator, Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors } from './theme';

export type Quality = 1080 | 1440;

type Props = {
  quality: Quality;
  onQualityChange: (q: Quality) => void;
  onOpen: (doc: { uri: string; name: string }) => void;
};

export default function HomeScreen({ quality, onQualityChange, onOpen }: Props) {
  const insets = useSafeAreaInsets();
  const [busy, setBusy] = useState(false);

  const pick = async () => {
    try {
      setBusy(true);
      const res = await DocumentPicker.getDocumentAsync({
        type: 'application/pdf',
        copyToCacheDirectory: true,
        multiple: false,
      });
      if (res.canceled || !res.assets?.length) return;
      const a = res.assets[0];
      onOpen({ uri: a.uri, name: a.name ?? 'Presentation' });
    } catch (e: any) {
      Alert.alert('Could not open file', String(e?.message ?? e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <View
      style={[
        styles.root,
        { paddingLeft: insets.left + 32, paddingRight: insets.right + 32, paddingTop: insets.top + 24, paddingBottom: insets.bottom + 24 },
      ]}
    >
      <View style={styles.left}>
        <View style={styles.logo}>
          <MaterialCommunityIcons name="presentation-play" size={30} color={colors.bg} />
        </View>
        <Text style={styles.title}>Slide Recorder</Text>
        <Text style={styles.subtitle}>
          Present your slides, write on them, and record your voice. Only the slide goes into the
          video, never the buttons.
        </Text>
        <View style={styles.tip}>
          <MaterialCommunityIcons name="information-outline" size={18} color={colors.accent} />
          <Text style={styles.tipText}>
            PowerPoint files: first save them as PDF. In PowerPoint use File → Export → PDF (on
            the phone: Share → PDF).
          </Text>
        </View>
      </View>

      <View style={styles.right}>
        <Pressable
          onPress={pick}
          disabled={busy}
          style={({ pressed }) => [styles.openBtn, pressed && { opacity: 0.85 }]}
        >
          {busy ? (
            <ActivityIndicator color={colors.bg} />
          ) : (
            <MaterialCommunityIcons name="file-pdf-box" size={26} color={colors.bg} />
          )}
          <Text style={styles.openText}>Open presentation (PDF)</Text>
        </Pressable>

        <Text style={styles.label}>Video quality</Text>
        <View style={styles.qualityRow}>
          {([1080, 1440] as Quality[]).map((q) => {
            const active = q === quality;
            return (
              <Pressable
                key={q}
                onPress={() => onQualityChange(q)}
                style={[styles.qualityCard, active && styles.qualityActive]}
              >
                <Text style={[styles.qualityTitle, active && { color: colors.accent }]}>{q}p</Text>
                <Text style={styles.qualityDesc}>
                  {q === 1080 ? 'Sharp, works on every phone' : 'Sharpest writing, bigger files'}
                </Text>
              </Pressable>
            );
          })}
        </View>
        <Text style={styles.note}>
          Videos are saved to Movies/SlideRecorder. To keep the quality, send them as a file, not
          as a WhatsApp video.
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg, flexDirection: 'row', gap: 40, alignItems: 'center' },
  left: { flex: 1, justifyContent: 'center' },
  right: { flex: 1, justifyContent: 'center' },
  logo: {
    width: 52, height: 52, borderRadius: 14, backgroundColor: colors.accent,
    alignItems: 'center', justifyContent: 'center', marginBottom: 16,
  },
  title: { color: colors.text, fontSize: 30, fontWeight: '800', letterSpacing: -0.5 },
  subtitle: { color: colors.textDim, fontSize: 15, lineHeight: 22, marginTop: 8, maxWidth: 420 },
  tip: {
    flexDirection: 'row', gap: 10, marginTop: 20, padding: 12, borderRadius: 12,
    backgroundColor: colors.panel, borderWidth: 1, borderColor: colors.border, maxWidth: 440,
  },
  tipText: { color: colors.textDim, fontSize: 13, lineHeight: 19, flex: 1 },
  openBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10,
    backgroundColor: colors.accent, borderRadius: 14, paddingVertical: 16,
  },
  openText: { color: colors.bg, fontSize: 17, fontWeight: '700' },
  label: { color: colors.textDim, fontSize: 13, fontWeight: '600', marginTop: 22, marginBottom: 8, textTransform: 'uppercase', letterSpacing: 0.8 },
  qualityRow: { flexDirection: 'row', gap: 12 },
  qualityCard: {
    flex: 1, padding: 14, borderRadius: 12, backgroundColor: colors.panel,
    borderWidth: 1.5, borderColor: colors.border,
  },
  qualityActive: { borderColor: colors.accent, backgroundColor: colors.panelRaised },
  qualityTitle: { color: colors.text, fontSize: 20, fontWeight: '800' },
  qualityDesc: { color: colors.textDim, fontSize: 12, marginTop: 2 },
  note: { color: colors.textDim, fontSize: 12, lineHeight: 17, marginTop: 14 },
});
