import { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  BackHandler,
  PermissionsAndroid,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as Sharing from 'expo-sharing';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  SlideRecorderView,
  type SlideRecorderViewRef,
  type Tool,
} from '../modules/slide-recorder';
import { BASE_BITRATE, colors, inkColors, inkWidths } from './theme';
import type { Quality } from './HomeScreen';

type RecState = 'idle' | 'starting' | 'recording' | 'paused' | 'saving';
type IconName = keyof typeof MaterialCommunityIcons.glyphMap;

type Props = {
  doc: { uri: string; name: string };
  quality: Quality;
  onExit: () => void;
};

export default function PresenterScreen({ doc, quality, onExit }: Props) {
  const insets = useSafeAreaInsets();
  const slideRef = useRef<SlideRecorderViewRef>(null);

  const [pageCount, setPageCount] = useState(0);
  const [page, setPage] = useState(0);
  const [tool, setTool] = useState<Tool>('pen');
  const [color, setColor] = useState(inkColors[1]);
  const [width, setWidth] = useState(inkWidths[1].value);
  const [showInk, setShowInk] = useState(false);

  const [rec, setRec] = useState<RecState>('idle');
  const [elapsed, setElapsed] = useState(0);
  const timer = useRef({ base: 0, since: 0 });

  // ---------- timer ----------
  useEffect(() => {
    if (rec !== 'recording') return;
    const id = setInterval(() => {
      setElapsed(timer.current.base + (Date.now() - timer.current.since));
    }, 250);
    return () => clearInterval(id);
  }, [rec]);

  // ---------- navigation ----------
  const goTo = useCallback(
    (p: number) => setPage((cur) => (pageCount ? Math.max(0, Math.min(pageCount - 1, p)) : cur)),
    [pageCount]
  );

  // ---------- recording ----------
  const start = async () => {
    const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.RECORD_AUDIO, {
      title: 'Microphone',
      message: 'The microphone is needed to record your voice with the slides.',
      buttonPositive: 'Allow',
    });
    if (granted !== PermissionsAndroid.RESULTS.GRANTED) {
      Alert.alert('Microphone needed', 'Allow the microphone in Settings to record your voice.');
      return;
    }
    try {
      setRec('starting');
      await slideRef.current?.startRecording(quality, BASE_BITRATE);
      timer.current = { base: 0, since: Date.now() };
      setElapsed(0);
      setRec('recording');
    } catch (e: any) {
      setRec('idle');
      Alert.alert('Could not start recording', String(e?.message ?? e));
    }
  };

  const pause = async () => {
    await slideRef.current?.pauseRecording();
    timer.current.base += Date.now() - timer.current.since;
    setElapsed(timer.current.base);
    setRec('paused');
  };

  const resume = async () => {
    await slideRef.current?.resumeRecording();
    timer.current.since = Date.now();
    setRec('recording');
  };

  const stop = async () => {
    try {
      setRec('saving');
      const r = await slideRef.current!.stopRecording();
      setRec('idle');
      const mb = (r.sizeBytes / 1024 / 1024).toFixed(1);
      Alert.alert(
        'Video saved',
        `${r.width}×${r.height}, ${mb} MB\nSaved in Movies/SlideRecorder (${r.fileName}).` +
          (r.galleryUri ? '' : '\n\nNote: it could not be copied to Movies, use Share to keep it.'),
        [
          {
            text: 'Share',
            onPress: () =>
              Sharing.shareAsync(r.fileUri, { mimeType: 'video/mp4', dialogTitle: 'Share lesson video' }).catch(
                () => {}
              ),
          },
          { text: 'OK' },
        ]
      );
    } catch (e: any) {
      setRec('idle');
      Alert.alert('Recording problem', String(e?.message ?? e));
    }
  };

  const isRecording = rec === 'recording' || rec === 'paused';

  const exit = useCallback(() => {
    if (rec === 'idle') {
      onExit();
      return;
    }
    Alert.alert('Recording in progress', 'Stop and save the recording first.');
  }, [rec, onExit]);

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      exit();
      return true;
    });
    return () => sub.remove();
  }, [exit]);

  const clearPage = () =>
    Alert.alert('Clear this slide?', 'All writing on this slide will be removed.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Clear', style: 'destructive', onPress: () => slideRef.current?.clearPage() },
    ]);

  // ---------- UI ----------
  const tools: { key: Tool; icon: IconName; label: string }[] = [
    { key: 'none', icon: 'hand-back-right', label: 'Move' },
    { key: 'pen', icon: 'pen', label: 'Pen' },
    { key: 'highlighter', icon: 'marker', label: 'Marker' },
    { key: 'eraser', icon: 'eraser', label: 'Eraser' },
    { key: 'laser', icon: 'laser-pointer', label: 'Laser' },
  ];

  return (
    <View style={[styles.root, { paddingLeft: insets.left, paddingRight: insets.right }]}>
      {/* LEFT TOOLBAR — not part of the video */}
      <ScrollView
        style={styles.sidebar}
        contentContainerStyle={[styles.sidebarContent, { paddingTop: insets.top + 8, paddingBottom: insets.bottom + 8 }]}
        showsVerticalScrollIndicator={false}
      >
        {tools.map((t) => (
          <ToolButton
            key={t.key}
            icon={t.icon}
            label={t.label}
            active={tool === t.key}
            onPress={() => {
              setTool(t.key);
              setShowInk(false);
            }}
          />
        ))}
        <Pressable onPress={() => setShowInk((v) => !v)} style={styles.colorBtn}>
          <View style={[styles.colorDot, { backgroundColor: color }]} />
          <Text style={styles.btnLabel}>Ink</Text>
        </Pressable>
        <ToolButton icon="undo" label="Undo" onPress={() => slideRef.current?.undo()} />
        <ToolButton icon="delete-sweep-outline" label="Clear" onPress={clearPage} />
      </ScrollView>

      {/* SLIDE — the only thing recorded */}
      <View style={styles.stage}>
        <SlideRecorderView
          ref={slideRef}
          style={StyleSheet.absoluteFill}
          source={doc.uri}
          page={page}
          tool={tool}
          color={color}
          strokeWidth={width}
          onLoad={(e) => setPageCount(e.nativeEvent.pageCount)}
          onSwipe={(e) => goTo(page + (e.nativeEvent.direction === 'next' ? 1 : -1))}
          onError={(e) => Alert.alert('Problem', e.nativeEvent.message, [{ text: 'OK', onPress: onExit }])}
        />
        {pageCount === 0 && (
          <View style={styles.loading} pointerEvents="none">
            <ActivityIndicator color={colors.accent} size="large" />
          </View>
        )}

        {showInk && (
          <View style={styles.inkPanel}>
            <View style={styles.swatches}>
              {inkColors.map((c) => (
                <Pressable
                  key={c}
                  onPress={() => {
                    setColor(c);
                    if (tool === 'none' || tool === 'eraser' || tool === 'laser') setTool('pen');
                  }}
                  style={[styles.swatch, { backgroundColor: c }, c === color && styles.swatchActive]}
                />
              ))}
            </View>
            <View style={styles.widthRow}>
              {inkWidths.map((w) => (
                <Pressable
                  key={w.label}
                  onPress={() => setWidth(w.value)}
                  style={[styles.widthBtn, w.value === width && styles.widthActive]}
                >
                  <View style={{ height: Math.max(2, w.value * 900), width: 26, borderRadius: 4, backgroundColor: color === '#111111' ? '#ddd' : color }} />
                  <Text style={styles.widthLabel}>{w.label}</Text>
                </Pressable>
              ))}
            </View>
          </View>
        )}
      </View>

      {/* RIGHT BAR — navigation and recording, not part of the video */}
      <ScrollView
        style={[styles.sidebar, styles.rightBar]}
        contentContainerStyle={[styles.sidebarContent, { paddingTop: insets.top + 8, paddingBottom: insets.bottom + 8 }]}
        showsVerticalScrollIndicator={false}
      >
        <ToolButton icon="close" label="Exit" onPress={exit} />
        <ToolButton icon="chevron-left" label="Back" onPress={() => goTo(page - 1)} disabled={page <= 0} />
        <Text style={styles.pageText}>
          {pageCount ? `${page + 1}/${pageCount}` : '–'}
        </Text>
        <ToolButton icon="chevron-right" label="Next" onPress={() => goTo(page + 1)} disabled={page >= pageCount - 1} />

        <View style={styles.divider} />

        {rec === 'idle' && <RecordButton onPress={start} />}
        {(rec === 'starting' || rec === 'saving') && (
          <View style={styles.busy}>
            <ActivityIndicator color={colors.record} />
            <Text style={styles.btnLabel}>{rec === 'saving' ? 'Saving' : 'Starting'}</Text>
          </View>
        )}
        {rec === 'recording' && <ToolButton icon="pause" label="Pause" onPress={pause} />}
        {rec === 'paused' && <ToolButton icon="play" label="Resume" onPress={resume} tint={colors.ok} />}
        {isRecording && <ToolButton icon="stop" label="Save" onPress={stop} tint={colors.record} />}
        {isRecording && (
          <View style={styles.timerBox}>
            <View style={[styles.recDot, rec === 'paused' && { backgroundColor: colors.textDim }]} />
            <Text style={styles.timer}>{fmt(elapsed)}</Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

function fmt(ms: number) {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  return `${m}:${String(s % 60).padStart(2, '0')}`;
}

function ToolButton(props: {
  icon: IconName;
  label: string;
  onPress: () => void;
  active?: boolean;
  disabled?: boolean;
  tint?: string;
}) {
  const { icon, label, onPress, active, disabled, tint } = props;
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [
        styles.btn,
        active && styles.btnActive,
        pressed && { opacity: 0.7 },
        disabled && { opacity: 0.3 },
      ]}
    >
      <MaterialCommunityIcons name={icon} size={24} color={tint ?? (active ? colors.bg : colors.text)} />
      <Text style={[styles.btnLabel, active && { color: colors.bg }]}>{label}</Text>
    </Pressable>
  );
}

function RecordButton({ onPress }: { onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.btn, pressed && { opacity: 0.7 }]}>
      <View style={styles.recOuter}>
        <View style={styles.recInner} />
      </View>
      <Text style={styles.btnLabel}>Record</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, flexDirection: 'row', backgroundColor: colors.bg },
  sidebar: { width: 72, flexGrow: 0, backgroundColor: colors.panel },
  rightBar: { width: 80 },
  sidebarContent: { alignItems: 'center', gap: 4 },
  stage: { flex: 1, backgroundColor: colors.bg },
  loading: { position: "absolute", left: 0, top: 0, right: 0, bottom: 0, alignItems: 'center', justifyContent: 'center' },
  btn: { width: 60, paddingVertical: 6, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  btnActive: { backgroundColor: colors.accent },
  btnLabel: { color: colors.textDim, fontSize: 10, marginTop: 2, fontWeight: '600' },
  colorBtn: { width: 60, paddingVertical: 6, alignItems: 'center' },
  colorDot: { width: 24, height: 24, borderRadius: 12, borderWidth: 2, borderColor: colors.text },
  pageText: { color: colors.text, fontSize: 13, fontWeight: '700', paddingVertical: 2 },
  divider: { height: 1, width: 44, backgroundColor: colors.border, marginVertical: 6 },
  busy: { height: 56, alignItems: 'center', justifyContent: 'center' },
  recOuter: {
    width: 30, height: 30, borderRadius: 15, borderWidth: 2.5, borderColor: colors.text,
    alignItems: 'center', justifyContent: 'center',
  },
  recInner: { width: 18, height: 18, borderRadius: 9, backgroundColor: colors.record },
  timerBox: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 4 },
  recDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.record },
  timer: { color: colors.text, fontSize: 13, fontVariant: ['tabular-nums'], fontWeight: '700' },
  inkPanel: {
    position: 'absolute', left: 8, top: 8, padding: 12, borderRadius: 14,
    backgroundColor: colors.panelRaised, borderWidth: 1, borderColor: colors.border, gap: 12,
  },
  swatches: { flexDirection: 'row', gap: 10 },
  swatch: { width: 30, height: 30, borderRadius: 15, borderWidth: 2, borderColor: 'transparent' },
  swatchActive: { borderColor: colors.accent, transform: [{ scale: 1.12 }] },
  widthRow: { flexDirection: 'row', gap: 8 },
  widthBtn: {
    flex: 1, alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 8,
    borderRadius: 10, borderWidth: 1, borderColor: colors.border,
  },
  widthActive: { borderColor: colors.accent },
  widthLabel: { color: colors.textDim, fontSize: 11 },
});
