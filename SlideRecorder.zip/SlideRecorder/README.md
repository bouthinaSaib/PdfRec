# Slide Recorder

Android app for teachers: open a presentation (PDF), write on the slides, and record
the slides with your voice in high quality. Only the slide area goes into the video —
buttons, status bar and notifications are never recorded.

## Features
- Open a PDF of your PowerPoint (PowerPoint: File → Export → PDF).
- Pen, highlighter, eraser and laser pointer; 7 ink colors, 3 widths, undo, clear slide.
- Swipe (with the "Move" tool) or use the arrows to change slides.
- Record / Pause / Resume / Save. Video 1080p or 1440p, H.264, ~16 Mbps at 1080p,
  AAC 48 kHz voice. Saved to `Movies/SlideRecorder` and shareable as a file.
- Slides are rendered directly at video resolution, so text and writing stay sharp.

Requires Android 10 or newer.

## Getting the APK (no Android Studio needed)
1. Create a new repository on GitHub and upload this whole folder to it.
2. Open the repository's **Actions** tab. The "Build Android APK" workflow runs
   automatically (or press **Run workflow**). It takes about 10–20 minutes.
3. Open the finished run and download **SlideRecorder-apk** under *Artifacts*.
   It is a .zip containing `app-release.apk`.
4. Copy the APK to your phone, open it and allow installing from this source.

## Project layout
- `App.tsx`, `src/` — React Native screens (home, presenter with toolbars).
- `modules/slide-recorder/` — native Kotlin module:
  - `SlideScene.kt` — PDF page, ink and laser drawing (shared by screen and video).
  - `SlideRecorderView.kt` — the on-screen slide view and touch handling.
  - `SlideVideoRecorder.kt` — MediaCodec H.264 + AAC encoder, pause/resume, saving.
- `.github/workflows/build-apk.yml` — cloud build of the APK.

## Building locally (optional)
```
npm install
npx expo prebuild --platform android
cd android && ./gradlew assembleRelease
```
