import { useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import HomeScreen, { type Quality } from './src/HomeScreen';
import PresenterScreen from './src/PresenterScreen';

export default function App() {
  const [doc, setDoc] = useState<{ uri: string; name: string } | null>(null);
  const [quality, setQuality] = useState<Quality>(1080);

  return (
    <SafeAreaProvider>
      <StatusBar hidden style="light" />
      {doc ? (
        <PresenterScreen doc={doc} quality={quality} onExit={() => setDoc(null)} />
      ) : (
        <HomeScreen quality={quality} onQualityChange={setQuality} onOpen={setDoc} />
      )}
    </SafeAreaProvider>
  );
}
