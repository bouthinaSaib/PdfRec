export { default as SlideRecorderView } from './src/SlideRecorderView';
export type * from './src/SlideRecorderView';
