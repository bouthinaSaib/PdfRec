package expo.modules.sliderecorder

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.view.GestureDetector
import android.view.MotionEvent
import expo.modules.kotlin.AppContext
import expo.modules.kotlin.Promise
import expo.modules.kotlin.viewevent.EventDispatcher
import expo.modules.kotlin.views.ExpoView
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * The slide area: shows the PDF page, handles pen/highlighter/eraser/laser,
 * and owns the recorder. Only what this view draws ends up in the video.
 */
@SuppressLint("ViewConstructor")
class SlideRecorderView(context: Context, appContext: AppContext) : ExpoView(context, appContext) {
  private val onLoad by EventDispatcher()
  private val onSwipe by EventDispatcher()
  private val onError by EventDispatcher()

  val scene = SlideScene(context.applicationContext)
  private val renderExecutor = Executors.newSingleThreadExecutor()
  private val recorderExecutor = Executors.newSingleThreadExecutor()

  private var source: String? = null
  private var displayBitmap: Bitmap? = null
  private var renderGeneration = 0

  var tool = Tool.NONE
  var inkColor = Color.parseColor("#1E3A8A")
  /** Ink width as a fraction of the page width. */
  var inkWidth = 0.0035f

  @Volatile private var recorder: SlideVideoRecorder? = null
  private var drawing = false

  private val density = resources.displayMetrics.density

  private val gestures = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
    override fun onDown(e: MotionEvent) = true
    override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
      if (abs(vx) > abs(vy) * 1.3f && abs(vx) > 600 * density) {
        onSwipe(mapOf("direction" to if (vx < 0) "next" else "previous"))
        return true
      }
      return false
    }
  })

  init {
    setWillNotDraw(false)
    setBackgroundColor(BG)
  }

  // ---------------- props ----------------

  fun setSource(uri: String?) {
    if (uri == source) return
    source = uri
    if (uri.isNullOrEmpty()) return
    renderExecutor.execute {
      try {
        scene.open(uri)
        post {
          onLoad(mapOf("pageCount" to scene.pageCount))
          requestPageRender()
        }
      } catch (e: Exception) {
        post { onError(mapOf("message" to ("Could not open this PDF: " + (e.message ?: "unknown error")))) }
      }
    }
  }

  fun setPage(index: Int) {
    if (scene.pageCount > 0 && index !in 0 until scene.pageCount) return
    if (index == scene.page) return
    scene.endStroke()
    scene.page = index
    requestPageRender()
    invalidate()
  }

  fun setToolName(name: String?) {
    tool = when (name) {
      "pen" -> Tool.PEN
      "highlighter" -> Tool.HIGHLIGHTER
      "eraser" -> Tool.ERASER
      "laser" -> Tool.LASER
      else -> Tool.NONE
    }
  }

  fun setColorString(c: String?) {
    try { if (c != null) inkColor = Color.parseColor(c) } catch (_: Exception) {}
  }

  // ---------------- rendering ----------------

  private fun requestPageRender() {
    if (width == 0 || height == 0 || scene.pageCount == 0) return
    val gen = ++renderGeneration
    val page = scene.page
    val rect = scene.pageRect(page, width.toFloat(), height.toFloat())
    val w = rect.width().roundToInt()
    val h = rect.height().roundToInt()
    renderExecutor.execute {
      val bmp = try { scene.renderPage(page, w, h) } catch (_: Exception) { null }
      post {
        if (gen == renderGeneration) {
          displayBitmap = bmp
          invalidate()
        } else {
          bmp?.recycle()
        }
      }
    }
  }

  override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
    super.onSizeChanged(w, h, oldw, oldh)
    requestPageRender()
  }

  override fun onDraw(canvas: Canvas) {
    super.onDraw(canvas)
    // Only use the cached bitmap if it belongs to the current page size.
    scene.drawScene(canvas, width.toFloat(), height.toFloat(), BG, displayBitmap)
    if (scene.laserActive()) postInvalidateOnAnimation()
  }

  // ---------------- touch ----------------

  @SuppressLint("ClickableViewAccessibility")
  override fun onTouchEvent(e: MotionEvent): Boolean {
    if (scene.pageCount == 0) return false
    if (tool == Tool.NONE) {
      gestures.onTouchEvent(e)
      return true
    }
    parent?.requestDisallowInterceptTouchEvent(true)
    val rect = scene.pageRect(scene.page, width.toFloat(), height.toFloat())
    val s = rect.width()
    fun nx(x: Float) = (x - rect.left) / s
    fun ny(y: Float) = (y - rect.top) / s

    when (e.actionMasked) {
      MotionEvent.ACTION_DOWN -> {
        when (tool) {
          Tool.PEN -> { scene.beginStroke(Tool.PEN, inkColor, inkWidth, nx(e.x), ny(e.y)); drawing = true }
          Tool.HIGHLIGHTER -> { scene.beginStroke(Tool.HIGHLIGHTER, inkColor, inkWidth * 4f, nx(e.x), ny(e.y)); drawing = true }
          Tool.ERASER -> scene.eraseAt(nx(e.x), ny(e.y), ERASER_DP * density / s)
          Tool.LASER -> scene.laserMove(nx(e.x), ny(e.y))
          else -> {}
        }
      }
      MotionEvent.ACTION_MOVE -> {
        for (i in 0 until e.historySize) handleMove(e.getHistoricalX(0, i), e.getHistoricalY(0, i), ::nx, ::ny, s)
        handleMove(e.x, e.y, ::nx, ::ny, s)
      }
      MotionEvent.ACTION_POINTER_DOWN -> {
        // A second finger (e.g. palm) – finish the current stroke.
        if (drawing) { scene.endStroke(); drawing = false }
      }
      MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
        if (drawing) { scene.endStroke(); drawing = false }
        if (tool == Tool.LASER) scene.laserUp()
      }
    }
    postInvalidateOnAnimation()
    return true
  }

  private fun handleMove(x: Float, y: Float, nx: (Float) -> Float, ny: (Float) -> Float, s: Float) {
    when (tool) {
      Tool.PEN, Tool.HIGHLIGHTER -> if (drawing) scene.extendStroke(nx(x), ny(y))
      Tool.ERASER -> scene.eraseAt(nx(x), ny(y), ERASER_DP * density / s)
      Tool.LASER -> scene.laserMove(nx(x), ny(y))
      else -> {}
    }
  }

  // ---------------- functions from JS ----------------

  fun undo() { scene.undo(); postInvalidate() }

  fun clearPage() { scene.clearPage(); postInvalidate() }

  fun startRecording(height: Int, bitrate: Int, promise: Promise) {
    recorderExecutor.execute {
      if (recorder != null) { promise.reject("E_BUSY", "Already recording", null); return@execute }
      if (scene.pageCount == 0) { promise.reject("E_NO_PDF", "Open a PDF first", null); return@execute }
      try {
        val r = SlideVideoRecorder(context.applicationContext, scene, height, bitrate)
        r.start()
        recorder = r
        post { keepScreenOn = true }
        promise.resolve(mapOf("width" to r.width, "height" to r.height, "bitrate" to r.bitrate))
      } catch (e: Throwable) {
        promise.reject("E_START", e.message ?: "Could not start recording", e)
      }
    }
  }

  fun pauseRecording() { recorder?.pause() }

  fun resumeRecording() { recorder?.resume() }

  fun stopRecording(promise: Promise) {
    recorderExecutor.execute {
      val r = recorder
      if (r == null) { promise.reject("E_IDLE", "Not recording", null); return@execute }
      recorder = null
      post { keepScreenOn = false }
      try {
        promise.resolve(r.stop())
      } catch (e: Throwable) {
        promise.reject("E_STOP", e.message ?: "Could not save the recording", e)
      }
    }
  }

  /** Called when React Native no longer uses this view. */
  fun destroy() {
    // Leaving the screen while recording: finish the file so nothing is lost.
    recorderExecutor.execute {
      val r = recorder
      recorder = null
      try { r?.stop() } catch (_: Throwable) {}
      renderExecutor.execute { scene.close() }
      renderExecutor.shutdown()
    }
    recorderExecutor.shutdown()
  }

  companion object {
    private val BG = Color.parseColor("#0F1115")
    private const val ERASER_DP = 14f
  }
}
