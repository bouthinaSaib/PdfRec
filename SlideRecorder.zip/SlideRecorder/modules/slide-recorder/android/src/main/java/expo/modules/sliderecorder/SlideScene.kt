package expo.modules.sliderecorder

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import java.io.File
import kotlin.math.hypot
import kotlin.math.max

enum class Tool { NONE, PEN, HIGHLIGHTER, ERASER, LASER }

/**
 * One drawn stroke. Coordinates are stored relative to the page WIDTH
 * (x in 0..1, y in 0..pageHeight/pageWidth), so the same stroke can be drawn
 * sharply at any size: on the phone screen and in the high-resolution video.
 */
class Stroke(val tool: Tool, val color: Int, val width: Float) {
  private var pts = FloatArray(128)
  var count = 0 // number of floats used (2 per point)
    private set
  private var cachedPath: Path? = null

  fun add(x: Float, y: Float) {
    if (count >= 2) {
      val dx = x - pts[count - 2]
      val dy = y - pts[count - 1]
      if (dx * dx + dy * dy < 1e-8f) return
    }
    if (count + 2 > pts.size) pts = pts.copyOf(pts.size * 2)
    pts[count++] = x
    pts[count++] = y
    cachedPath = null
  }

  fun hits(x: Float, y: Float, radius: Float): Boolean {
    val r = radius + width / 2f
    var i = 0
    while (i < count) {
      if (hypot(pts[i] - x, pts[i + 1] - y) <= r) return true
      i += 2
    }
    return false
  }

  fun path(): Path {
    cachedPath?.let { return it }
    val p = Path()
    if (count >= 2) {
      p.moveTo(pts[0], pts[1])
      if (count == 2) {
        p.lineTo(pts[0] + 0.0001f, pts[1])
      } else {
        // Smooth the line with quadratic curves through the midpoints.
        var i = 2
        while (i < count - 2) {
          val mx = (pts[i] + pts[i + 2]) / 2f
          val my = (pts[i + 1] + pts[i + 3]) / 2f
          p.quadTo(pts[i], pts[i + 1], mx, my)
          i += 2
        }
        p.lineTo(pts[count - 2], pts[count - 1])
      }
    }
    cachedPath = p
    return p
  }
}

/**
 * Everything that appears in the slide area (and therefore in the video):
 * the PDF page, the ink, and the laser pointer. The on-screen view and the
 * recorder both draw through [drawScene], so the video matches the screen
 * exactly, while the app's buttons are never part of it.
 */
class SlideScene(private val context: Context) {
  val lock = Any()
  private val pdfLock = Any()

  private var pfd: ParcelFileDescriptor? = null
  private var renderer: PdfRenderer? = null
  private var pageSizes: Array<FloatArray> = emptyArray()

  @Volatile var page = 0
  @Volatile var pageCount = 0
    private set

  private val strokes = HashMap<Int, ArrayList<Stroke>>()
  private var current: Stroke? = null

  private val laserPts = ArrayList<FloatArray>() // x, y, time(ms)
  @Volatile private var laserDown = false
  @Volatile private var laserLastMs = 0L

  private val inkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
    style = Paint.Style.STROKE
    strokeCap = Paint.Cap.ROUND
    strokeJoin = Paint.Join.ROUND
  }
  private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
  private val laserPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
  private val whitePaint = Paint().apply { color = Color.WHITE }

  // ---------- PDF ----------

  fun open(uriString: String) {
    close()
    val uri = Uri.parse(uriString)
    val fd = if (uri.scheme == null || uri.scheme == "file") {
      ParcelFileDescriptor.open(File(uri.path ?: uriString), ParcelFileDescriptor.MODE_READ_ONLY)
    } else {
      context.contentResolver.openFileDescriptor(uri, "r")
        ?: throw IllegalStateException("Cannot open file")
    }
    val r = PdfRenderer(fd)
    val sizes = Array(r.pageCount) { i ->
      val p = r.openPage(i)
      val s = floatArrayOf(p.width.toFloat(), p.height.toFloat())
      p.close()
      s
    }
    synchronized(pdfLock) {
      pfd = fd
      renderer = r
      pageSizes = sizes
    }
    synchronized(lock) { strokes.clear(); current = null; laserPts.clear() }
    pageCount = sizes.size
    page = 0
  }

  fun close() {
    synchronized(pdfLock) {
      try { renderer?.close() } catch (_: Exception) {}
      try { pfd?.close() } catch (_: Exception) {}
      renderer = null
      pfd = null
      pageSizes = emptyArray()
    }
    pageCount = 0
  }

  /** Height / width of a page (1 / aspect). */
  fun pageRatio(index: Int): Float {
    val s = synchronized(pdfLock) { pageSizes.getOrNull(index) } ?: return 9f / 16f
    return if (s[0] > 0f) s[1] / s[0] else 9f / 16f
  }

  /** The page rectangle that fits inside a box of [w] x [h] pixels. */
  fun pageRect(index: Int, w: Float, h: Float): RectF {
    val ratio = pageRatio(index)
    var pw = w
    var ph = w * ratio
    if (ph > h) { ph = h; pw = h / ratio }
    val l = (w - pw) / 2f
    val t = (h - ph) / 2f
    return RectF(l, t, l + pw, t + ph)
  }

  /** Renders a page sharply at exactly [w] x [h] pixels (vector quality). */
  fun renderPage(index: Int, w: Int, h: Int): Bitmap? {
    if (w <= 0 || h <= 0) return null
    return synchronized(pdfLock) {
      val r = renderer
      if (r == null || index < 0 || index >= r.pageCount) {
        null
      } else {
        val p = r.openPage(index)
        try {
          val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
          bmp.eraseColor(Color.WHITE)
          val m = Matrix()
          m.setScale(w / p.width.toFloat(), h / p.height.toFloat())
          p.render(bmp, null, m, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
          bmp
        } finally {
          p.close()
        }
      }
    }
  }

  // ---------- Ink ----------

  fun beginStroke(tool: Tool, color: Int, width: Float, x: Float, y: Float) {
    synchronized(lock) {
      val s = Stroke(tool, color, width)
      s.add(x, y)
      current = s
      strokes.getOrPut(page) { ArrayList() }.add(s)
    }
  }

  fun extendStroke(x: Float, y: Float) {
    synchronized(lock) { current?.add(x, y) }
  }

  fun endStroke() {
    synchronized(lock) { current = null }
  }

  fun eraseAt(x: Float, y: Float, radius: Float): Boolean {
    synchronized(lock) {
      val list = strokes[page] ?: return false
      return list.removeAll { it.hits(x, y, radius) }
    }
  }

  fun undo() {
    synchronized(lock) {
      val list = strokes[page] ?: return
      if (list.isNotEmpty()) list.removeAt(list.size - 1)
      current = null
    }
  }

  fun clearPage() {
    synchronized(lock) { strokes[page]?.clear(); current = null }
  }

  // ---------- Laser ----------

  fun laserMove(x: Float, y: Float) {
    val now = System.currentTimeMillis()
    synchronized(lock) {
      laserPts.add(floatArrayOf(x, y, (now % 1_000_000L).toFloat()))
      laserDown = true
      laserLastMs = now
    }
  }

  fun laserUp() {
    laserDown = false
    laserLastMs = System.currentTimeMillis()
  }

  /** True while the laser still needs redrawing (it fades out). */
  fun laserActive(): Boolean =
    laserDown || System.currentTimeMillis() - laserLastMs < LASER_FADE_MS + 50

  // ---------- Drawing ----------

  /**
   * Draws the slide with its ink into a box of [w] x [h] pixels.
   * [pageBitmap] must already be rendered at the size of the page rect.
   */
  fun drawScene(canvas: Canvas, w: Float, h: Float, background: Int, pageBitmap: Bitmap?) {
    canvas.drawColor(background)
    val idx = page
    if (pageCount == 0) return
    val rect = pageRect(idx, w, h)
    if (pageBitmap != null) {
      canvas.drawBitmap(pageBitmap, null, rect, bitmapPaint)
    } else {
      canvas.drawRect(rect, whitePaint)
    }

    val save = canvas.save()
    canvas.clipRect(rect)
    canvas.translate(rect.left, rect.top)
    val scale = rect.width()
    canvas.scale(scale, scale)

    synchronized(lock) {
      strokes[idx]?.let { list ->
        for (s in list) {
          inkPaint.color = s.color
          inkPaint.strokeWidth = s.width
          inkPaint.alpha = if (s.tool == Tool.HIGHLIGHTER) 90 else 255
          inkPaint.strokeCap = if (s.tool == Tool.HIGHLIGHTER) Paint.Cap.SQUARE else Paint.Cap.ROUND
          canvas.drawPath(s.path(), inkPaint)
        }
      }
      drawLaser(canvas)
    }
    canvas.restoreToCount(save)
  }

  private fun drawLaser(canvas: Canvas) {
    if (laserPts.isEmpty()) return
    val nowMs = System.currentTimeMillis()
    val now = (nowMs % 1_000_000L).toFloat()
    // Forget old trail points.
    laserPts.removeAll { age(now, it[2]) > LASER_TRAIL_MS }
    val fade = if (laserDown) 1f else
      max(0f, 1f - (nowMs - laserLastMs).toFloat() / LASER_FADE_MS)
    if (fade <= 0f) { laserPts.clear(); return }

    for (p in laserPts) {
      val a = (1f - age(now, p[2]) / LASER_TRAIL_MS).coerceIn(0f, 1f) * fade
      laserPaint.color = Color.argb((110 * a).toInt(), 255, 30, 30)
      canvas.drawCircle(p[0], p[1], LASER_RADIUS * 0.7f, laserPaint)
    }
    val last = laserPts.lastOrNull() ?: return
    laserPaint.color = Color.argb((90 * fade).toInt(), 255, 40, 40)
    canvas.drawCircle(last[0], last[1], LASER_RADIUS * 2.2f, laserPaint)
    laserPaint.color = Color.argb((255 * fade).toInt(), 255, 20, 20)
    canvas.drawCircle(last[0], last[1], LASER_RADIUS, laserPaint)
    laserPaint.color = Color.argb((220 * fade).toInt(), 255, 220, 220)
    canvas.drawCircle(last[0], last[1], LASER_RADIUS * 0.35f, laserPaint)
  }

  private fun age(now: Float, t: Float): Float {
    var d = now - t
    if (d < 0) d += 1_000_000f
    return d
  }

  companion object {
    const val LASER_RADIUS = 0.007f
    const val LASER_TRAIL_MS = 350f
    const val LASER_FADE_MS = 400f
  }
}
