package expo.modules.sliderecorder

import expo.modules.kotlin.Promise
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class SlideRecorderModule : Module() {
  override fun definition() = ModuleDefinition {
    Name("SlideRecorder")

    View(SlideRecorderView::class) {
      Events("onLoad", "onSwipe", "onError")

      Prop("source") { view: SlideRecorderView, uri: String? -> view.setSource(uri) }
      Prop("page") { view: SlideRecorderView, page: Int -> view.setPage(page) }
      Prop("tool") { view: SlideRecorderView, tool: String? -> view.setToolName(tool) }
      Prop("color") { view: SlideRecorderView, color: String? -> view.setColorString(color) }
      Prop("strokeWidth") { view: SlideRecorderView, width: Double -> view.inkWidth = width.toFloat() }

      AsyncFunction("undo") { view: SlideRecorderView -> view.undo() }
      AsyncFunction("clearPage") { view: SlideRecorderView -> view.clearPage() }

      AsyncFunction("startRecording") { view: SlideRecorderView, height: Int, bitrate: Int, promise: Promise ->
        view.startRecording(height, bitrate, promise)
      }
      AsyncFunction("pauseRecording") { view: SlideRecorderView -> view.pauseRecording() }
      AsyncFunction("resumeRecording") { view: SlideRecorderView -> view.resumeRecording() }
      AsyncFunction("stopRecording") { view: SlideRecorderView, promise: Promise ->
        view.stopRecording(promise)
      }

      OnViewDestroys { view: SlideRecorderView -> view.destroy() }
    }
  }
}
