package expo.modules.sliderecorder

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.Surface
import java.io.File
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Records ONLY the slide scene (page + ink + laser) plus the microphone into an MP4.
 * Frames are drawn straight into the video encoder at full resolution, so the
 * app's buttons, the status bar and notifications never appear in the video.
 */
class SlideVideoRecorder(
  private val context: Context,
  private val scene: SlideScene,
  private val targetHeight: Int,
  private val requestedBitrate: Int
) {
  companion object {
    private const val TAG = "SlideRecorder"
    private const val FPS = 30
    private const val SAMPLE_RATE = 48_000
    private const val AUDIO_BITRATE = 160_000
    private const val TIMEOUT_US = 10_000L
  }

  var width = 0
    private set
  var height = 0
    private set
  var bitrate = 0
    private set
  lateinit var outputFile: File
    private set

  private lateinit var videoCodec: MediaCodec
  private lateinit var audioCodec: MediaCodec
  private lateinit var inputSurface: Surface
  private lateinit var audioRecord: AudioRecord
  private lateinit var muxer: SafeMuxer

  @Volatile private var running = false
  @Volatile var paused = false
    private set
  @Volatile private var error: Throwable? = null

  private var startNs = 0L
  private val pauses = ArrayList<LongArray>() // [startNs, endNs]
  private var pausedAtNs = -1L

  private var videoThread: Thread? = null
  private var audioThread: Thread? = null

  // ---------------- public API ----------------

  @SuppressLint("MissingPermission")
  fun start() {
    val dir = File(context.cacheDir, "recordings")
    dir.mkdirs()
    dir.listFiles()?.forEach { it.delete() } // remove older temporary copies
    val stamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
    outputFile = File(dir, "Lesson_$stamp.mp4")

    setupVideo()
    try {
      setupAudio()
    } catch (e: Throwable) {
      releaseVideo()
      throw e
    }
    muxer = SafeMuxer(outputFile.absolutePath)

    startNs = System.nanoTime()
    running = true
    audioRecord.startRecording()
    videoThread = Thread({ videoLoop() }, "slide-video").apply { priority = Thread.MAX_PRIORITY; start() }
    audioThread = Thread({ audioLoop() }, "slide-audio").apply { priority = Thread.MAX_PRIORITY; start() }
  }

  fun pause() {
    synchronized(pauses) {
      if (paused || !running) return
      pausedAtNs = System.nanoTime()
      paused = true
    }
  }

  fun resume() {
    synchronized(pauses) {
      if (!paused) return
      pauses.add(longArrayOf(pausedAtNs, System.nanoTime()))
      pausedAtNs = -1L
      paused = false
    }
  }

  /** Stops, finalizes the MP4 and copies it to Movies/SlideRecorder. Blocking. */
  fun stop(): Map<String, Any?> {
    if (paused) resume()
    running = false
    videoThread?.join(15_000)
    audioThread?.join(15_000)
    try { audioRecord.stop() } catch (_: Exception) {}
    audioRecord.release()
    try { videoCodec.stop() } catch (_: Exception) {}
    try { audioCodec.stop() } catch (_: Exception) {}
    videoCodec.release()
    audioCodec.release()
    inputSurface.release()
    val muxerOk = muxer.finish()

    error?.let { throw RuntimeException("Recording failed: ${it.message}", it) }
    if (!muxerOk || outputFile.length() == 0L) throw RuntimeException("The recording is empty")

    val galleryUri = saveToMovies(outputFile)
    return mapOf(
      "fileUri" to "file://${outputFile.absolutePath}",
      "galleryUri" to galleryUri,
      "fileName" to outputFile.name,
      "width" to width,
      "height" to height,
      "bitrate" to bitrate,
      "sizeBytes" to outputFile.length().toDouble()
    )
  }

  // ---------------- video ----------------

  private fun setupVideo() {
    val ratio = scene.pageRatio(scene.page) // height / width of the slide
    val candidates = listOf(targetHeight, 1080, 720).distinct().filter { it <= targetHeight }
    val mime = MediaFormat.MIMETYPE_VIDEO_AVC
    val list = MediaCodecList(MediaCodecList.REGULAR_CODECS)

    for (h in candidates) {
      val (w, hh) = videoSize(h, ratio)
      val probe = MediaFormat.createVideoFormat(mime, w, hh)
      val name = list.findEncoderForFormat(probe) ?: continue
      val info = list.codecInfos.firstOrNull { it.name == name } ?: continue
      val caps = info.getCapabilitiesForType(mime)
      val vcaps = caps.videoCapabilities
      if (!vcaps.isSizeSupported(w, hh)) continue

      val br = vcaps.bitrateRange.clamp(scaledBitrate(w, hh))
      val high = caps.profileLevels.filter { it.profile == MediaCodecInfo.CodecProfileLevel.AVCProfileHigh }
        .maxByOrNull { it.level }

      // Try High profile first (best quality), then the encoder's default.
      for (useHigh in listOf(true, false)) {
        if (useHigh && high == null) continue
        val fmt = MediaFormat.createVideoFormat(mime, w, hh).apply {
          setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
          setInteger(MediaFormat.KEY_BIT_RATE, br)
          setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
          setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
          setInteger(MediaFormat.KEY_MAX_B_FRAMES, 0)
          if (useHigh && high != null) {
            setInteger(MediaFormat.KEY_PROFILE, high.profile)
            setInteger(MediaFormat.KEY_LEVEL, high.level)
          }
        }
        var codec: MediaCodec? = null
        try {
          codec = MediaCodec.createByCodecName(name)
          codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
          inputSurface = codec.createInputSurface()
          codec.start()
          videoCodec = codec
          width = w; height = hh; bitrate = br
          Log.i(TAG, "Video ${w}x$hh @ ${br / 1_000_000} Mbps, high=$useHigh, codec=$name")
          return
        } catch (e: Exception) {
          Log.w(TAG, "Encoder config failed (high=$useHigh, ${w}x$hh): ${e.message}")
          try { codec?.release() } catch (_: Exception) {}
        }
      }
    }
    throw RuntimeException("This phone has no video encoder for the selected quality")
  }

  /** Fits the slide in a 16:9 box of the requested height, multiples of 8. */
  private fun videoSize(boxH: Int, ratio: Float): Pair<Int, Int> {
    val boxW = (boxH * 16f / 9f)
    var w = boxW
    var h = boxW * ratio
    if (h > boxH) { h = boxH.toFloat(); w = boxH / ratio }
    fun r8(v: Float) = maxOf(8, (v / 8f).roundToInt() * 8)
    return r8(w) to r8(h)
  }

  /** Requested bitrate is for 1920x1080; scale it for other sizes. */
  private fun scaledBitrate(w: Int, h: Int): Int {
    val factor = (w.toDouble() * h) / (1920.0 * 1080.0)
    return (requestedBitrate * factor.coerceIn(0.45, 2.0)).toInt()
  }

  private fun videoLoop() {
    val info = MediaCodec.BufferInfo()
    var recBitmap: Bitmap? = null
    var recPage = -1
    val frameNs = 1_000_000_000L / FPS
    var next = System.nanoTime()
    try {
      while (running) {
        if (!paused) {
          val page = scene.page
          val rect = scene.pageRect(page, width.toFloat(), height.toFloat())
          val bw = rect.width().roundToInt()
          val bh = rect.height().roundToInt()
          if (page != recPage || recBitmap == null || recBitmap.width != bw || recBitmap.height != bh) {
            recBitmap?.recycle()
            recBitmap = scene.renderPage(page, bw, bh)
            recPage = page
          }
          val canvas = inputSurface.lockHardwareCanvas()
          try {
            scene.drawScene(canvas, width.toFloat(), height.toFloat(), Color.BLACK, recBitmap)
          } finally {
            inputSurface.unlockCanvasAndPost(canvas)
          }
        }
        drainVideo(info, false)

        next += frameNs
        val sleepNs = next - System.nanoTime()
        if (sleepNs > 0) {
          Thread.sleep(sleepNs / 1_000_000L, (sleepNs % 1_000_000L).toInt())
        } else if (sleepNs < -frameNs * 3) {
          next = System.nanoTime() // fell behind, don't try to catch up
        }
      }
      videoCodec.signalEndOfInputStream()
      drainVideo(info, true)
    } catch (t: Throwable) {
      Log.e(TAG, "Video thread error", t)
      if (error == null) error = t
    } finally {
      recBitmap?.recycle()
    }
  }

  private var domainOffsetNs: Long? = null
  private var lastVideoPtsUs = -1L

  private fun drainVideo(info: MediaCodec.BufferInfo, endOfStream: Boolean) {
    var waited = 0
    while (true) {
      val idx = videoCodec.dequeueOutputBuffer(info, if (endOfStream) TIMEOUT_US else 0L)
      when {
        idx == MediaCodec.INFO_TRY_AGAIN_LATER -> {
          if (!endOfStream || ++waited > 300) return
        }
        idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> muxer.addTrack(true, videoCodec.outputFormat)
        idx >= 0 -> {
          val buf = videoCodec.getOutputBuffer(idx)
          if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
          if (info.size > 0 && buf != null) {
            info.presentationTimeUs = videoPts(info.presentationTimeUs)
            muxer.write(true, buf, info)
          }
          videoCodec.releaseOutputBuffer(idx, false)
          if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
        }
      }
    }
  }

  /** Converts the frame's capture time into video time, removing paused periods. */
  private fun videoPts(rawUs: Long): Long {
    val rawNs = rawUs * 1000L
    val offset = domainOffsetNs ?: run {
      val now = System.nanoTime()
      // Surface timestamps normally use the same monotonic clock; guard just in case.
      val o = if (abs(now - rawNs) < 5_000_000_000L) 0L else now - rawNs
      domainOffsetNs = o
      o
    }
    val t = rawNs + offset
    val pausedNs = synchronized(pauses) { pauses.filter { it[1] <= t }.sumOf { it[1] - it[0] } }
    var pts = maxOf(0L, (t - startNs - pausedNs) / 1000L)
    if (pts <= lastVideoPtsUs) pts = lastVideoPtsUs + 1
    lastVideoPtsUs = pts
    return pts
  }

  private fun releaseVideo() {
    try { videoCodec.release() } catch (_: Exception) {}
    try { inputSurface.release() } catch (_: Exception) {}
  }

  // ---------------- audio ----------------

  @SuppressLint("MissingPermission")
  private fun setupAudio() {
    val minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
    if (minBuf <= 0) throw RuntimeException("Microphone is not available")
    val rec = AudioRecord(
      MediaRecorder.AudioSource.MIC,
      SAMPLE_RATE,
      AudioFormat.CHANNEL_IN_MONO,
      AudioFormat.ENCODING_PCM_16BIT,
      maxOf(minBuf * 4, SAMPLE_RATE / 2)
    )
    if (rec.state != AudioRecord.STATE_INITIALIZED) {
      rec.release()
      throw RuntimeException("Could not open the microphone. Check the microphone permission.")
    }
    val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SAMPLE_RATE, 1).apply {
      setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
      setInteger(MediaFormat.KEY_BIT_RATE, AUDIO_BITRATE)
      setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16_384)
    }
    val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
    try {
      codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
      codec.start()
    } catch (e: Exception) {
      codec.release()
      rec.release()
      throw e
    }
    audioRecord = rec
    audioCodec = codec
  }

  private fun audioLoop() {
    val info = MediaCodec.BufferInfo()
    val chunk = ByteArray(2048)
    var samples = 0L
    try {
      while (running) {
        val n = audioRecord.read(chunk, 0, chunk.size)
        if (n > 0 && !paused) {
          var off = 0
          while (off < n) {
            val idx = audioCodec.dequeueInputBuffer(TIMEOUT_US)
            if (idx < 0) { drainAudio(info, false); continue }
            val buf = audioCodec.getInputBuffer(idx) ?: continue
            buf.clear()
            val len = minOf(n - off, buf.remaining())
            buf.put(chunk, off, len)
            val pts = samples * 1_000_000L / SAMPLE_RATE
            audioCodec.queueInputBuffer(idx, 0, len, pts, 0)
            samples += len / 2
            off += len
          }
        }
        drainAudio(info, false)
      }
      // End of stream
      var idx = -1
      var tries = 0
      while (idx < 0 && tries++ < 100) {
        idx = audioCodec.dequeueInputBuffer(TIMEOUT_US)
        if (idx < 0) drainAudio(info, false)
      }
      if (idx >= 0) {
        audioCodec.queueInputBuffer(idx, 0, 0, samples * 1_000_000L / SAMPLE_RATE, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
        drainAudio(info, true)
      }
    } catch (t: Throwable) {
      Log.e(TAG, "Audio thread error", t)
      if (error == null) error = t
    }
  }

  private var lastAudioPtsUs = -1L

  private fun drainAudio(info: MediaCodec.BufferInfo, endOfStream: Boolean) {
    var waited = 0
    while (true) {
      val idx = audioCodec.dequeueOutputBuffer(info, if (endOfStream) TIMEOUT_US else 0L)
      when {
        idx == MediaCodec.INFO_TRY_AGAIN_LATER -> {
          if (!endOfStream || ++waited > 300) return
        }
        idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> muxer.addTrack(false, audioCodec.outputFormat)
        idx >= 0 -> {
          val buf = audioCodec.getOutputBuffer(idx)
          if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
          if (info.size > 0 && buf != null) {
            if (info.presentationTimeUs <= lastAudioPtsUs) info.presentationTimeUs = lastAudioPtsUs + 1
            lastAudioPtsUs = info.presentationTimeUs
            muxer.write(false, buf, info)
          }
          audioCodec.releaseOutputBuffer(idx, false)
          if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
        }
      }
    }
  }

  // ---------------- saving ----------------

  private fun saveToMovies(file: File): String? {
    return try {
      val resolver = context.contentResolver
      val values = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/SlideRecorder")
        put(MediaStore.Video.Media.IS_PENDING, 1)
      }
      val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
      val uri = resolver.insert(collection, values) ?: return null
      resolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out, 1 shl 20) } }
      values.clear()
      values.put(MediaStore.Video.Media.IS_PENDING, 0)
      resolver.update(uri, values, null, null)
      uri.toString()
    } catch (e: Exception) {
      Log.e(TAG, "Could not save to Movies", e)
      null
    }
  }
}

/** MediaMuxer that waits for both tracks and buffers early samples. */
private class SafeMuxer(path: String) {
  private val muxer = MediaMuxer(path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
  private var videoTrack = -1
  private var audioTrack = -1
  private var started = false
  private var wroteVideo = false
  private val pending = ArrayList<Triple<Boolean, ByteBuffer, MediaCodec.BufferInfo>>()

  @Synchronized
  fun addTrack(isVideo: Boolean, format: MediaFormat) {
    if (started) return
    if (isVideo && videoTrack < 0) videoTrack = muxer.addTrack(format)
    if (!isVideo && audioTrack < 0) audioTrack = muxer.addTrack(format)
    if (videoTrack >= 0 && audioTrack >= 0) {
      muxer.start()
      started = true
      for ((v, b, i) in pending) writeNow(v, b, i)
      pending.clear()
    }
  }

  @Synchronized
  fun write(isVideo: Boolean, buf: ByteBuffer, info: MediaCodec.BufferInfo) {
    buf.position(info.offset)
    buf.limit(info.offset + info.size)
    if (!started) {
      val copy = ByteBuffer.allocateDirect(info.size)
      copy.put(buf)
      copy.flip()
      val ci = MediaCodec.BufferInfo()
      ci.set(0, info.size, info.presentationTimeUs, info.flags)
      pending.add(Triple(isVideo, copy, ci))
      return
    }
    writeNow(isVideo, buf, info)
  }

  private fun writeNow(isVideo: Boolean, buf: ByteBuffer, info: MediaCodec.BufferInfo) {
    muxer.writeSampleData(if (isVideo) videoTrack else audioTrack, buf, info)
    if (isVideo) wroteVideo = true
  }

  @Synchronized
  fun finish(): Boolean {
    var ok = started && wroteVideo
    try {
      if (started) muxer.stop()
    } catch (e: Exception) {
      ok = false
    }
    try { muxer.release() } catch (_: Exception) {}
    return ok
  }
}
