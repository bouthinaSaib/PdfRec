import { requireNativeView } from 'expo';
import * as React from 'react';
import type { ViewProps } from 'react-native';

export type Tool = 'none' | 'pen' | 'highlighter' | 'eraser' | 'laser';

export type RecordingInfo = { width: number; height: number; bitrate: number };

export type SavedRecording = {
  fileUri: string;
  galleryUri: string | null;
  fileName: string;
  width: number;
  height: number;
  bitrate: number;
  sizeBytes: number;
};

export type SlideRecorderViewProps = ViewProps & {
  /** file:// or content:// URI of a PDF */
  source: string;
  page: number;
  tool: Tool;
  color: string;
  /** Ink width as a fraction of the page width (e.g. 0.0035) */
  strokeWidth: number;
  onLoad?: (e: { nativeEvent: { pageCount: number } }) => void;
  onSwipe?: (e: { nativeEvent: { direction: 'next' | 'previous' } }) => void;
  onError?: (e: { nativeEvent: { message: string } }) => void;
};

/** Functions available on the view's ref. */
export type SlideRecorderViewRef = {
  undo(): Promise<void>;
  clearPage(): Promise<void>;
  startRecording(height: number, bitrate: number): Promise<RecordingInfo>;
  pauseRecording(): Promise<void>;
  resumeRecording(): Promise<void>;
  stopRecording(): Promise<SavedRecording>;
};

const NativeView: React.ComponentType<
  SlideRecorderViewProps & { ref?: React.Ref<SlideRecorderViewRef> }
> = requireNativeView('SlideRecorder');

export default NativeView;
